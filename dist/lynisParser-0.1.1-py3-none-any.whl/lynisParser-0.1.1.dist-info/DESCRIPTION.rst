# lynisParser
Prototype parser for Lynis reports as a stepping stone to a Dradis integration


